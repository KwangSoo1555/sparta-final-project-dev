export class JwtInput {
  readonly userId: number;
}
