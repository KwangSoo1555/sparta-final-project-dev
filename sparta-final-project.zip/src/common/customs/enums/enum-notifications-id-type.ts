export enum NotificationIdTypes {
  JOBS_ID = "JOBS_ID",
  NOTICE_ID = "NOTICE_ID",
}
