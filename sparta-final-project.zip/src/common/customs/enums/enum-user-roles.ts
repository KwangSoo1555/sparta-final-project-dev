export enum UserRoles {
  USER = "USER",
  ADMIN = "ADMIN",
}
