export enum NotificationSenderIdTypes {
  CUSTOMER_ID = "CUSTOMER_ID",
  OWNER_ID = "OWNER_ID",
  USER_ID = "USER_ID",
  RECEIVER_ID = "RECEIVER_ID",
  SENDER_ID = "SENDER_ID",
}
