export class CreateBlacklistDto {}
