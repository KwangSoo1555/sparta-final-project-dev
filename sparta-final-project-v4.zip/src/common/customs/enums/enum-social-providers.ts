export enum SocialProviders {
  LOCAL = "LOCAL",
  GOOGLE = "GOOGLE",
  NAVER = "NAVER",
  KAKAO = "KAKAO",
}
