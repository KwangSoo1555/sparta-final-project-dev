export class Blacklist {}
